# Simple Flask User Web App

## Features
- User signup & login
- Profile and password change
- Image upload with gallery
- Create text posts
- SQLite database
- Basic HTML interface

## Setup

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the app
```bash
python app.py
```

### 3. Deploy on Render
- Connect GitHub repo to Render.
- Use `gunicorn app:app` as the start command.

## Folder Structure
- `app.py`: Main Flask app.
- `uploads/`: Uploaded images (create if not exists).
- `app.db`: SQLite database (auto-created).
